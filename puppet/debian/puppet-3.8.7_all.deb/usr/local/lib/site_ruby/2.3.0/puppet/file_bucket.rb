# stub
module Puppet::FileBucket
  class BucketError < RuntimeError; end
end
